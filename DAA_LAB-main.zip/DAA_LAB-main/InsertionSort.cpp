#include <iostream>
using namespace std;

int main() {

    int arr[] = {12, 11, 13, 5, 6};
    int n = 5;

    
    for(int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;

        while(j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }

    cout << "Sorted array: [";
    for(int i = 0; i < n; i++) {
        cout << arr[i];
        if(i != n-1)
            cout << ", ";
    }
    cout << "]";

    return 0;
}
